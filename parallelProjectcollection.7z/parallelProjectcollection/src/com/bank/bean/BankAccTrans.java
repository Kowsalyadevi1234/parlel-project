package com.bank.bean;

	public class BankAccTrans {
	   private long bkAccfrom;
	    long bkAccTo;
	    int tranId;
	    String tranType;
	    String cusName;
	    String bkBran;
	    String bkAccType;
	    long bkPhoneno;
	    int bkBalOld;
	    int bkBalNew;
	    public long getBkAccfrom() {
	        return bkAccfrom;
	    }
	    public void setBkAccfrom(long bkAccfrom) {
	        this.bkAccfrom = bkAccfrom;
	    }
	    public long getBkAccTo() {
	        return bkAccTo;
	    }
	    public void setBkAccTo(long bkAccTo) {
	        this.bkAccTo = bkAccTo;
	    }
	    public int getTranId() {
	        return tranId;
	    }
	    public void setTranId(int tranId) {
	        this.tranId = tranId;
	    }
	    public String getTranType() {
	        return tranType;
	    }
	    public void setTranType(String tranType) {
	        this.tranType = tranType;
	    }
	    public String getCusName() {
	        return cusName;
	    }
	    public void setCusName(String cusName) {
	        this.cusName = cusName;
	    }
	    public String getBkBran() {
	        return bkBran;
	    }
	    public void setBkBran(String bkBran) {
	        this.bkBran = bkBran;
	    }
	    public String getBkAccType() {
	        return bkAccType;
	    }
	    public void setBkAccType(String bkAccType) {
	        this.bkAccType = bkAccType;
	    }
	    public long getBkPhoneno() {
	        return bkPhoneno;
	    }
	    public void setBkPhoneno(long bkPhoneno) {
	        this.bkPhoneno = bkPhoneno;
	    }
	    public int getBkBalOld() {
	        return bkBalOld;
	    }
	    public void setBkBalOld(int bkBalOld) {
	        this.bkBalOld = bkBalOld;
	    }
	    public int getBkBalNew() {
	        return bkBalNew;
	    }
	    public void setBkBalNew(int bkBalNew) {
	        this.bkBalNew = bkBalNew;
	    }
	    @Override
	    public String toString() {
	        return "Bank Transactions \n Account Send=" + bkAccfrom + ", Account To Get=" + bkAccTo + ", Transaction Id=" + tranId + ", Transaction Type="
	                + tranType + ", Account Holder Name=" + cusName + ", Account having in Branch=" + bkBran + ", Account Type=" + bkAccType + ", Account Holder Phone Number="
	                + bkPhoneno + ", Old Balance=" + bkBalOld + ", New Balance=" + bkBalNew ;
	    }
	    
	    
	}
