package com.bank.dao;

 

import java.util.List;

import com.bank.bean.BankAcc;
import com.bank.bean.BankAccTrans;

 

public interface BankAccDaoInter 
{
     long createAcc(BankAcc acc);
     int showAccDetails(Long BankAccNo);
     long depositBankAcc(long BankAccNoDep, int amount);
     long withDrawBankAcc(long BankAccNo1,int amt);
     long fundTran(long BankAccNo1, long BankAccNo2, int fundTran);
     List<BankAccTrans> printTrans();
}