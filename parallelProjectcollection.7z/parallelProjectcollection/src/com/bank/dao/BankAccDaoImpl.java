package com.bank.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bank.bean.BankAcc;
import com.bank.bean.BankAccTrans;
import com.bank.except.AccountNotFoundException;

public class BankAccDaoImpl implements BankAccDaoInter {
	Map<Long, BankAcc> banksAcc = new HashMap<Long, BankAcc>();
	Map<BankAccTrans, Long> banksAccTrans = new HashMap<BankAccTrans, Long>();
//store the account details
	public long createAcc(BankAcc Acc) {

		 banksAcc.put(Acc.getBkAcc(), Acc);
		 
		 return Acc.getBkAcc();
		
	}

	//store the balance details
	public int showAccDetails(Long bankAccNo) throws AccountNotFoundException {
		BankAcc show = banksAcc.get(bankAccNo);
		if (show == null) {
			throw new AccountNotFoundException("no account found for this account no");
		}
		return show.getBkBal();
	}

	//store the old and new balance details
	public long depositBankAcc(long bankAccNo, int amount) {
		BankAcc deposit = banksAcc.get(bankAccNo);
		int oldBal = deposit.getBkBal();
		int newBal = oldBal + amount;
		deposit.setBkBal(newBal);

		BankAccTrans bkTran1 = new BankAccTrans();
		bkTran1.setTranId(0000);
		bkTran1.setBkBalOld(oldBal);
		bkTran1.setBkBalNew(newBal);
		bkTran1.setBkAccType("Deposit");
		banksAccTrans.put(bkTran1, bankAccNo);
		System.out.println(banksAccTrans.size());
		return newBal;
	}

	
	public long withDrawBankAcc(long BankAccNo1, int amt) {
		BankAcc withDraw = banksAcc.get(BankAccNo1);
		int oldBal = withDraw.getBkBal();
		int newBal = oldBal - amt;
		withDraw.setBkBal(newBal);

		BankAccTrans bkTran2 = new BankAccTrans();
		bkTran2.setTranId(0000);
		bkTran2.setBkBalOld(oldBal);
		bkTran2.setBkBalNew(newBal);
		bkTran2.setBkAccType("WithDraw");
		banksAccTrans.put(bkTran2, BankAccNo1);
		System.out.println(banksAccTrans.size());

		return newBal;
	}

	
	public long fundTran(long bankAccNo1, long bankAccNo2, int fundTran) {
		BankAcc accNo1 = banksAcc.get(bankAccNo1);
		BankAcc accNo2 = banksAcc.get(bankAccNo2);
		int sendAmt = accNo1.getBkBal() - fundTran;
		int revAmt = accNo2.getBkBal() + fundTran;
		accNo1.setBkBal(sendAmt);
		accNo2.setBkBal(revAmt);

		BankAccTrans bkTran3 = new BankAccTrans();
		bkTran3.setTranId(0000);
		bkTran3.setBkAccfrom(bankAccNo1);
		bkTran3.setBkAccTo(bankAccNo2);
		bkTran3.setBkBalOld(sendAmt);
		bkTran3.setBkBalNew(revAmt);
		bkTran3.setBkAccType("Fund Tranfers");
		banksAccTrans.put(bkTran3, bankAccNo1);
		System.out.println(banksAccTrans.size());

		return sendAmt;
	}

	
	public List<BankAccTrans> printTrans() {
		List<BankAccTrans> list = new ArrayList<BankAccTrans>(banksAccTrans.keySet());

		return list;
	}

	public long BankAccDaoImpl(BankAcc bank) {
		// TODO Auto-generated method stub
		return 0;
	}

}
