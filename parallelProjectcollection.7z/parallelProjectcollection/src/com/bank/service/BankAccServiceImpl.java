package com.bank.service;

import java.util.List;

import com.bank.bean.BankAcc;
import com.bank.bean.BankAccTrans;
import com.bank.dao.BankAccDaoImpl;
import com.bank.dao.BankAccDaoInter;

public class BankAccServiceImpl implements BankAccServiceInter {
	BankAccDaoInter dao = new BankAccDaoImpl();

	
	public long createAcc(BankAcc Acc) {
		
		return dao.createAcc(Acc);
	}

	
	public int showAccDetails(long BankAccNo) {
		int show = dao.showAccDetails(BankAccNo);
		return show;
	}

	public long depositBankAcc(long BankAccNoDep, int amount) {
		long deposit = dao.depositBankAcc(BankAccNoDep, amount);
		return deposit;
	}

	
	public long withDrawBankAcc(long BankAccNo1, int amt) {
		long withdraw = dao.withDrawBankAcc(BankAccNo1, amt);
		return withdraw;
	}

	
	public long fundTran(long BankAccNo1, long BankAccNo2, int fundTran) {
		long fundTrans = dao.fundTran(BankAccNo1, BankAccNo2, fundTran);
		return fundTrans;
	}

	
	public List<BankAccTrans> printTrans() {

		return dao.printTrans();
	}

	
	public boolean bkName(String bkName) {
		if (bkName.matches("[A-Z][a-zA-Z]*"))
			return true;
		else

			return false;
	}

	
	public boolean mobNo(Long mobNo) {
		String mob = Long.toString(mobNo);
		if (mob.matches("[6-9][0-9]{9}"))
			return true;
		else
			return false;
	}

}
