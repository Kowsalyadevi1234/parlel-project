package com.bank.service;

	 

	import java.util.List;

import com.bank.bean.BankAcc;
import com.bank.bean.BankAccTrans;

	 

	public interface BankAccServiceInter
	{
	    long createAcc(BankAcc Acc);
	    int showAccDetails(long BankAccNo);
	    long depositBankAcc(long BankAccNoDep, int amount);
	    long withDrawBankAcc(long BankAccNo1,int amt);
	    long fundTran(long AccNo1,long AccNo2,int fundTran);
	     List<BankAccTrans> printTrans();
	     boolean bkName(String bkName);
	     boolean mobNo(Long mobNo);
	}
