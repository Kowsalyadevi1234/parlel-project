package com.pro1.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="acc")
public class Account {
	@Column(length=10)
	String custName;
	@Column(length=10)
	String branchName;
	@Column(length=10)
	String accType;
	long balance;
	@Id
	@GeneratedValue
	@Column
	long accNo;
	@Column(length=10)
	long custNum;
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public long getCustNum() {
		return custNum;
	}
	public void setCustNum(long custNum) {
		this.custNum = custNum;
	}
	@Override
	public String toString() {
		return "Account [custName=" + custName + ", branchName=" + branchName + ", accType=" + accType + ", balance="
				+ balance + ", accNo=" + accNo + ", custNum=" + custNum + "]";
	}
	
	
	
}
//Account main Class