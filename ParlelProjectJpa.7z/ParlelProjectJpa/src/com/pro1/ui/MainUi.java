package com.pro1.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.pro1.bean.Account;
import com.pro1.service.BankService;
import com.pro1.service.BankServiceImpl;

public class MainUi 
{
	static ApplicationContext ctx=new ClassPathXmlApplicationContext("Beans.xml");
	static BankService service=ctx.getBean("EmpService",BankServiceImpl.class);
	
	
	//static BankService service=new BankServiceImpl(); 
static Scanner scanner =new Scanner(System.in);

public static void main(String[] args) {
	
	
while(true)
{
	System.out.println("Welcome to the Application");
	System.out.println("****1************************");
	System.out.println("1. Create Account");
	System.out.println("2. Show Balance");
	System.out.println("3. Deposit");
	System.out.println("4. Withdraw");
	System.out.println("5. Fund Transfer");
	System.out.println("6. Print Transaction");
	System.out.println("Enter your Choice");
	int option=scanner.nextInt();
	switch (option) {
	case 1:
		//System.out.println("Enter the Name ");
		String custName;
		boolean isname;
		do {
			System.out.println("Enter your name");
			custName = scanner.next();
			isname = service.custName(custName);
			if (!isname) {
				System.out.println("only alphabets are allowed in names");
			}

		} while (!isname);
		long mobNo;
		Boolean isnumber;
		do {
			System.out.println("enter your mobno");
			mobNo = scanner.nextLong();
			isnumber = service.mobNo(mobNo);
			if (!isnumber) {
				System.out.println("enter valid mobile number");
			}
		} while (!isnumber);
		//String custName1=scanner.next();
		
		System.out.println("Enter the Branch Name : ");
		String branchName=scanner.next();
		System.out.println("Enter the Account Type('Savings' or 'Current') : ");
		String accType=scanner.next();
		System.out.println("Enter the Account Opening Balance : ");
		long balance=scanner.nextLong();
		//long accNo=custNum+1000;
		Account account=new Account();
		
		
		//account.setAccNo(accNo);
		account.setAccType(accType);
		account.setBalance(balance);
		account.setBranchName(branchName); 
		account.setCustName(custName);
		account.setCustNum(mobNo);
	long accNum=service.createAccount(account);
		System.out.println("Account created successfully with Account Number"+accNum);
		
break;
	case 2:
		System.out.println("Enter the Account Number : ");
		long accNo1=scanner.nextLong();
		long balan=service.accountBalance(accNo1);
		System.out.println("Balance in Account is "+balan);
		System.out.println("Balance Displayed");
	break;
	case 3:
		System.out.println("Enter the Account Number : ");
		 accNo1=scanner.nextLong();
		System.out.println("Enter the Amount to be Deposited : ");
		long depAmt=scanner.nextLong();
		 long a1=service.depositAmt(accNo1,depAmt);
		System.out.println("Balance in Account is: "+a1);
		System.out.println("Deposit Done Successfully");
	break;
	case 4:
		 Account a=new Account();
		System.out.println("Enter the Account Number : ");
		 accNo1=scanner.nextLong();
		System.out.println("Enter the Amount to be WithDrawn : ");
		long withAmt=scanner.nextLong();
		long a2=service.withdrawAmt(accNo1,withAmt);
		System.out.println("Balance in Account is: "+a2);
		System.out.println("Balance Displayed");
	break;
	case 5:
		long a11;
		System.out.println("Enter the Sender Account number");
		 accNo1=scanner.nextLong();
		System.out.println("Enter the receiver Account number");
		long accNo2=scanner.nextLong();
		System.out.println("Enter the Amount to transfer");
		 long amt=scanner.nextLong();
		 a11=service.transfer(accNo1,accNo2,amt);
		System.out.println("Amount Transfered");
		System.out.println("Balance in Sender Account is: "+a11);
		//System.out.println("Balance in Receiver Account is: "+service.accountBalance(accNo2));
	
	break;
	case 6:
		System.out.println("Showing all the Transaction");
		service.printTransactions();

	 
     
	
		break;
	case 7:
		System.out.println("Thank You");
		System.exit(0);
		break;
	default: 
		System.out.println("Wrong Choice!!!!!!");
	}
}
}


} //main ui
