package com.pro1.service;

import java.util.List;

import com.pro1.bean.Account;
import com.pro1.bean.Transaction;

public interface BankService {
long createAccount(Account account);
long accountBalance(Long accNo1);
long depositAmt(long accNo1, long depAmt);
long withdrawAmt(long accNo1, long withAmt);
long transfer(long accNo1, long accNo2, long amt);
void printTransactions();
boolean custName(String custName);
Boolean mobNo(long mobNo);

}
//service