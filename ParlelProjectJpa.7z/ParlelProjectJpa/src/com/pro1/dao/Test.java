package com.pro1.dao;

import static org.junit.Assert.*;

public class Test {

	@org.junit.Test
	public void test() {
		int bal=500;
		int result=bal+500;
		int expres=1000;
		assertEquals(result, expres);
	}

	@org.junit.Test
	public void test1() {
		int bal=500;
		int result=bal+500;
		int expres=100;
		assertEquals(result, expres);
	}

}
