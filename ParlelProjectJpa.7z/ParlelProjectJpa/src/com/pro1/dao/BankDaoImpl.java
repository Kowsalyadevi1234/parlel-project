package com.pro1.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.pro1.bean.Account;
import com.pro1.bean.Transaction;

@Repository

public class BankDaoImpl implements BankDao {
	
	
	//EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
@PersistenceContext
	private EntityManager entityManager;
	




public void setEntityManager(EntityManager entityManager) {
	this.entityManager = entityManager;
}


@Override
	@Transactional
	public long createAccount(Account account) {
		entityManager.persist(account);
		return account.getAccNo();
	}
	

	@Override
	@Transactional
	public long accountBalance(Long accNo1) {
		Account account = entityManager.find(Account.class, accNo1);
        return account.getBalance();
		
	}

	@Override
	@Transactional
	public long depositAmt(long accNo1, long depAmt) {
		Account account = entityManager.find(Account.class, accNo1);
        long oldbalance=account.getBalance();
        long newBalance=oldbalance+depAmt;
        account.setBalance(newBalance);
        entityManager.merge(account);
        
        Transaction t=new Transaction();
        t.setFromAccount(accNo1);
        t.setOldBalance(oldbalance);
        t.setNewBalance(newBalance);
        t.setTransactionType("deposit");
        entityManager.persist(t);
        
		return newBalance;
	}

	@Override
	@Transactional
	public long withdrawAmt(long accNo1, long withAmt) {
		Account account = entityManager.find(Account.class, accNo1);
        long oldbalance=account.getBalance();
        long newBalance=oldbalance-withAmt;
        account.setBalance(newBalance);
        entityManager.merge(account);
        Transaction t=new Transaction();
        t.setFromAccount(accNo1);
        t.setOldBalance(oldbalance);
        t.setNewBalance(newBalance);
        t.setTransactionType("withdraw");
        entityManager.persist(t);
        
        
		return newBalance;
		
	}

	@Override
	@Transactional
	public long transfer(long accNo1, long accNo2, long amt) {
		
		Account account = entityManager.find(Account.class, accNo1);
        long oldbalance=account.getBalance();
        long newBalance=oldbalance-amt;
        account.setBalance(newBalance);
        entityManager.merge(account);
        
        Transaction t=new Transaction();
        t.setFromAccount(accNo1);
        t.setOldBalance(oldbalance);
        t.setNewBalance(newBalance);
        t.setTransactionType("fund transfer");
        entityManager.persist(t);
        
        
        
        Account account1 = entityManager.find(Account.class, accNo2);
        long oldbalance1=account1.getBalance();
        long newBalance1=oldbalance1+amt;
        account1.setBalance(newBalance1);
        entityManager.merge(account1);
        
        Transaction t1=new Transaction();
        t1.setFromAccount(accNo2);
        t1.setOldBalance(oldbalance1);
        t1.setNewBalance(newBalance1);
        t1.setTransactionType("fund transfer");
        entityManager.persist(t1);
		
        return newBalance;
		
	}

	@Override
	@Transactional
	public void printTransactions() {
		TypedQuery<Transaction> q2=entityManager.createQuery("select c from Transaction c",Transaction.class);
        List<Transaction> l1=q2.getResultList();
        for(Transaction em1:l1)
        {
            System.out.println(em1.getTransId()+"  "+em1.getFromAccount()+"  "+em1.getToAccount()+"  "+em1.getOldBalance()+"  "+em1.getNewBalance()+"  "+em1.getTransactionType());
        }
	}

	
	
	}