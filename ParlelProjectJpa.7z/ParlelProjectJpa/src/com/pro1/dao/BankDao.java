package com.pro1.dao;

import com.pro1.bean.Account;

public interface BankDao {
	long createAccount(Account account);
	long accountBalance(Long accNo1);
	long depositAmt(long accNo1, long depAmt);
	long withdrawAmt(long accNo1, long withAmt);
	long transfer(long accNo1, long accNo2, long amt);

	void printTransactions();

}


//dao