package com.cap.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.EmployeeDao;
import com.cap.entities.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	EmployeeDao empDao;

	@Override
	public List<Employee> createEmployee(Employee emp) {
		empDao.save(emp);
		return empDao.findAll();
	}

	@Override
	public Employee findEmployeeById(long eid) {
		return empDao.findById(eid).get();
	}

}
