package com.cap.service;

import java.util.List;

import com.cap.entities.Employee;

public interface EmployeeService {
	public List<Employee> createEmployee(Employee emp);
	
	public Employee findEmployeeById(long eid);

}
