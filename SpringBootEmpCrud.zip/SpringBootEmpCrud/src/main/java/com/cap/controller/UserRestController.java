package com.cap.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.entities.Employee;
import com.cap.service.EmployeeService;

@RestController
@RequestMapping("/Bank")
public class UserRestController {
	@Autowired
	EmployeeService empService;
	
	@PostMapping("/CreateAccount")
	public List<Employee> createAccount(@RequestBody Employee emp){
		return empService.createEmployee(emp);
	}
	
	@GetMapping("/FindById")
	public Employee findByEmployeeId(@PathVariable Long eid){
		return empService.findEmployeeById(eid);
	}

}
