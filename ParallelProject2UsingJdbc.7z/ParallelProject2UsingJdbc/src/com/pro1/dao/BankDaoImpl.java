package com.pro1.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.pro1.bean.Account;
import com.pro1.bean.Transaction;

public class BankDaoImpl implements BankDao {
	Connection conn = DBConnect.getConnection();
	@Override
	public long createAccount(Account account) {
		long accNum = 0;
		try {
			PreparedStatement stmt = conn.prepareStatement("insert into account values(?,?,?,?,accNoseq.nextval,?)");
			stmt.setString(1, account.getCustName());
			stmt.setString(2, account.getBranchName());
			stmt.setString(3, account.getAccType());
			stmt.setDouble(4, account.getBalance());
			stmt.setLong(5, account.getCustNum());

			int i = stmt.executeUpdate();
			if (i > 0) {
				PreparedStatement stmt1 = conn.prepareStatement("select accNoseq.currval from account");
				ResultSet rs = stmt1.executeQuery();
				rs.next();
				accNum = rs.getLong(1);
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return accNum;
	}

	@Override
	public long accountBalance(Long accNo1) {
		long balance = 0;
		try {
			PreparedStatement stmt = conn.prepareStatement("select Balance from account where accNo=?");
			stmt.setLong(1, accNo1);
			ResultSet rs1 = stmt.executeQuery();
			rs1.next();
			balance = rs1.getInt(1);
		} catch (SQLException e) {
			System.out.println("invalid number");
		}
		return balance;

	}

	@Override
	public long depositAmt(long accNo1, long depAmt) {
		long deposit = 0;
		PreparedStatement stmt2;
		try {
			stmt2 = conn.prepareStatement("Select Balance from account where accNo=?");
			stmt2.setLong(1, accNo1);
			ResultSet rs2 = stmt2.executeQuery();
			rs2.next();
			deposit = rs2.getLong(1) + depAmt;
			
			PreparedStatement p = conn.prepareStatement("update account set Balance=? where accNo=?");
			p.setLong(1,deposit);
			p.setLong(2,accNo1);
			int res=p.executeUpdate();
			if(res>0)
			{
				PreparedStatement stmt=conn.prepareStatement("insert into transaction values(trans.nextVal,?,?,?,?,?)");
				stmt.setLong(1,accNo1);
				stmt.setLong(2,accNo1);
				stmt.setLong(3,depAmt);
				stmt.setLong(4,deposit);
				stmt.setString(5,"Deposit");
				stmt.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
			return deposit;
		
	}

	@Override

	public long withdrawAmt(long accNo1, long withAmt) {
		long withdraw=0 ;
		PreparedStatement stmt2;

		try {
			stmt2 = conn.prepareStatement("Select balance from account where accNo=?");
			stmt2.setLong(1, accNo1);
			ResultSet rs2 = stmt2.executeQuery();
			rs2.next();
			withdraw = rs2.getLong(1)-withAmt;
		
			
			PreparedStatement p = conn.prepareStatement("update account set balance=? where accNo=?");
			p.setLong(1, withAmt);
			p.setLong(2, accNo1);
			int res=p.executeUpdate();
			if(res>0)
			{
				PreparedStatement stmt=conn.prepareStatement("insert into transaction values(trans.nextVal,?,?,?,?,?)");
				stmt.setLong(1,accNo1);
				stmt.setLong(2,accNo1);
				stmt.setLong(3,withAmt);
				stmt.setLong(4,withAmt);
				stmt.setString(5,"withdraw");
				stmt.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
			return withAmt;
		
	}

	@Override
	public long transfer(long accNo1, long accNo2, long amt) {
		long preBal = 0;
		long newBal = 0;
		PreparedStatement stmt2,stmt3;
		try {
			
			stmt2 = conn.prepareStatement("Select balance from account where accNo=?");
			stmt2.setLong(1, accNo1);
			ResultSet rs2 = stmt2.executeQuery();
			rs2.next();
			preBal = rs2.getLong(1)-amt;			
			PreparedStatement p = conn.prepareStatement("update account set balance=? where accNo=?");
			p.setLong(1, preBal);
			p.setLong(2, accNo1);
			int res=p.executeUpdate();
			 if(res>0)
	            {
	                
	                PreparedStatement st1=conn.prepareStatement("insert into transaction values(trans.nextval,?,?,?,?,?)");
	                st1.setLong(1, accNo1);
	                st1.setLong(2, accNo2);
	                st1.setLong(3, preBal);
	                st1.setLong(4, newBal);
	                st1.setString(5, "fund transfer");
	                st1.executeUpdate();
	                
	            }
	            
			
			
			stmt3 = conn.prepareStatement("Select Balance from account where accNo=?");
			stmt3.setLong(1, accNo2);
			ResultSet rs3 = stmt3.executeQuery();
			rs3.next();
			newBal = rs2.getLong(1)+amt;
			PreparedStatement p1 = conn.prepareStatement("update account set Balance=? where accNo=?");
			p1.setLong(1,newBal);
			p1.setLong(2,accNo2);
			p1.executeUpdate();
			 if(res>0)
	            {
	                
	                PreparedStatement st2=conn.prepareStatement("insert into transaction values(trans.nextval,?,?,?,?,?)");
	                st2.setLong(1, accNo1);
	                st2.setLong(2, accNo2);
	                st2.setLong(3, preBal);
	                st2.setLong(4, newBal);
	                st2.setString(5,"fund transfer");
	                st2.executeUpdate();
	                
	            }
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		return newBal;
	}

	@Override
	public void printTransactions() {
		
	   Transaction tr=new Transaction();    
	   Connection conn=DBConnect.getConnection();
       try {
           PreparedStatement stmt9=conn.prepareStatement("select * from transaction");
           ResultSet rs=stmt9.executeQuery();
           while(rs.next())
           {
               int transId=rs.getInt(1);
               int toAccount=rs.getInt(3);
               int fromAccount=rs.getInt(2);
               int oldBalance=rs.getInt(4);
               int newBalance=rs.getInt(5);
               String transactionType=rs.getString(6);
               tr.setTransId(transId);
               tr.setToAccount(toAccount);
               tr.setFromAccount(fromAccount);
               tr.setOldBalance(oldBalance);
               tr.setNewBalance(newBalance);
               tr.setTransactionType(transactionType);
               
               
               
               System.out.println(tr);
           }   
	}catch(SQLException e) {
			e.printStackTrace();
		}
       }
}