let num=12;
let a1=[1,2,3,'a'];
var x:number[];
x=[1,2,3,4,];
for(let i in x)
{
    console.log(i);
}
x.push(19);
num=x.pop();
let numberList:number[]=[1,2,3];
let numList:Array<number>=[1,2,3];