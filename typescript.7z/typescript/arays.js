var num = 12;
var a1 = [1, 2, 3, 'a'];
var x;
x = [1, 2, 3, 4,];
for (var i in x) {
    console.log(i);
}
x.push(19);
num = x.pop();
var numberList = [1, 2, 3];
var numList = [1, 2, 3];
