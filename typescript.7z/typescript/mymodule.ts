export class person
{
 private firstname:string;
 private lastname:string;
 constructor(_firstname:string,_lastname:string){
 this.firstname=_firstname;
 this.lastname=_lastname;
 }
 fullName():string{
 return this.firstname + " " +this.lastname;
 }}
 class Emp extends person{
 id:number;
 constructor(_id: number, _firstname:string,_lastname:string)
 {
 super(_firstname,_lastname);
 this.id = _id;
 
 }
 showDetails(): void{
 console.log(this.id+ " " + this.fullName());
 }
 }
 let e1=new Emp(1,"nivedha","sekar");
e1.showDetails();