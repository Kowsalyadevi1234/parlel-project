class person
{
    firstname:string;
    lastnmae:string;
}
var p=new person();
p.firstname="suresh";
p.firstname="kowsi";
console.log(p.firstname+""+p.lastnmae);