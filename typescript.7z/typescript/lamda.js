function add(x, y) {
    return x + y;
}
var sum = function (x, y) {
    return x + y;
};
add(23, 32);
sum(23, 34);
var sum1 = function (x, y) { return x + y; };
sum1(234, 345);
var sum2 = function (x, y) { return x + y; };
sum1(234, 345);
var sum3 = function (x, y) { return x + y; };
sum1(234, 345);
var sum4 = function () { return console.log("function without return"); };
sum4();
