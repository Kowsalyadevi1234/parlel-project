class employee{
    static empid:number;
    name:string;
    constructor(empid:number,name:string){
        employee.empid=empid;
        this.name=name;
    }
    displayDetails()
        {
return employee.empid+":"+this.name;
        }
    
}
employee.empid=213123;
var emp=new employee(13,"kowsi");
console.log(emp.displayDetails());