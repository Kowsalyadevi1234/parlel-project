function add(x:number,...y:number[]):number{
    let result=x;
    for(var i=0;i<y.length;i++){
result +=y[i];

    
}
return result;
}
let result1=add(23,25);
let result2=add(23,25);
console.log(result1);
console.log(result2);
