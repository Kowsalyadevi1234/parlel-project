function add(x:number,y:number):number{
    return x+y;
}
let sum = function(x:number,y:number):number{
return x+y;
}
add(23,32);
sum(23,34);
let sum1 = (x:number,y:number)=>x+y;
    sum1(234,345);
    let sum2 = (x:number,y:number)=>{return x+y};
    sum1(234,345);
    let sum3 = (x:number,y:number)=>x+y;
    sum1(234,345);
    let sum4 = ()=>console.log("function without return")
    sum4();