var employee = /** @class */ (function () {
    function employee(empid, name) {
        employee.empid = empid;
        this.name = name;
    }
    employee.prototype.displayDetails = function () {
        return employee.empid + ":" + this.name;
    };
    return employee;
}());
employee.empid = 213123;
var emp = new employee(13, "kowsi");
console.log(emp.displayDetails());
