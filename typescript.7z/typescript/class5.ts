import {student,employee}from"./mymodule";
let st=new student(1,"mohan");
let result1=st.showdetails();
console.log("student etails:"+result1);
let emp=new employee("kowsi","hello");
let result2=emp.showdetails();
console.log("employee detals:"+result2);

