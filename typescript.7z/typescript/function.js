function addition(a, b) {
    return a + b;
}
var sum = addition(100, 200);
var sum1 = addition('welcome', 200);
console.log(sum);
var x;
function addition1(a, b) {
    return a + b;
}
var sum4 = addition(100, 200);
