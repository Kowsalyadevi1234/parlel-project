var a:number=12;
var b:number;
var c:String;
var d:undefined;
var e:boolean;
var f=null;
a=16;
b=30;
d="kowsalya";
c="kowsi";
e=false;
console.log(a+b);
console.log(c)