function addition(a,b)
{
    return a+b;
}
var sum=addition(100,200);
var sum1=addition('welcome',200);
console.log(sum);
var x:number;
function addition1(a:number,b:number)
{
    return a+b;
}
var sum4=addition(100,200);

function add2(a: number,b: number,c?:);
{
return a+b+c;
}
var sum6=add2(100,200);
var sum7=add2(100,200,300);
console.log(sum6);
console.log(sum7);