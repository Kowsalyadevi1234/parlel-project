package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParalleProjectViaRestFulServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParalleProjectViaRestFulServiceApplication.class, args);
	}

}