package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
@Table(name="bank1")
@Entity
public class BankEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "a")
	@SequenceGenerator(name = "a", sequenceName = "banksq2")
	@Column(length = 15)
	private Long accNo;
	/*@Min(4)
	@Max(20)*/
	@Column(length = 15)
	private String pwd;
	/*@Min(4)
	@Max(20)*/
	@Column(length = 15)
	private String name;
	/*@Min(4)
	@Max(20)*/
	@Column(length = 10)
	private String address;
	@Column(length = 20)
	private Double bal;
	/*@Min(9)
	@Max(11)*/
	@Column(length = 10)
	private String mobNo;

	public Long getAccNo() {
		return accNo;
	}

	public void setAccNo(Long accNo) {
		this.accNo = accNo;
	}

	public BankEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Double getBal() {
		return bal;
	}

	public void setBal(Double bal) {
		this.bal = bal;
	}

	public String getMobNo() {
		return mobNo;
	}

	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}

	@Override
	public String toString() {
		return "BankEntity [accNo=" + accNo + ", pwd=" + pwd + ", name=" + name + ", address=" + address + ", bal="
				+ bal + ", mobNo=" + mobNo + "]";
	}

	public BankEntity(Long accNo, String pwd, String name, String address, Double bal, String mobNo) {
		super();
		this.accNo = accNo;
		this.pwd = pwd;
		this.name = name;
		this.address = address;
		this.bal = bal;
		this.mobNo = mobNo;
	}

}
